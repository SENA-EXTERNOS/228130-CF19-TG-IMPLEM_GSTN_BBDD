function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6qP8D6D2cbO":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

